import { useDadosContext } from '../../context/Dados';
import Botao from '../../components/Botao';
import TelaErro from '../../components/TelaErro';
import Cabecalho from '../../components/Cabecalho';
import styles from './Home.module.css'

export default function Home() {

    const {dados} = useDadosContext();


    if (!dados?.cpf) {
        return (
            <TelaErro />
        )
    } else {
        return (
            <>
                <Cabecalho perfil={dados?.perfil} />
                <div className={styles.container}>
                    <div>
                        <h1>Olá {dados?.apelido},</h1>
                        <h3>Seja bem-vindo(a) ao nosso sistema!</h3>
                        <h3>Escolha o que deseja fazer agora:</h3>
                        <Botao url='/'>Sair</Botao>
                        <Botao url='/dados'>Dados Pessoais</Botao>
                    </div>
                </div>
            </>
        )
    }

}
