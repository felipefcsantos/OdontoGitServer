import React from 'react'
import Input from '../../components/Input'
import styles from './Login.module.css'

export default function Login() {
  return (
    <div className={styles.container}>
        <Input/>
    </div>
  )
}
