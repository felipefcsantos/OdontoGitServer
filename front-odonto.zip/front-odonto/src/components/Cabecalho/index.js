import React from 'react'
import logo from '../../images/logo.png'
import styles from './Cabecalho.module.css'

export default function Cabecalho({ perfil }) {

    let perfilUsuario = ""

    if (perfil === "A") {
        perfilUsuario = "Adminstrador(a)"
    } else {
        if (perfil === "P") {
            perfilUsuario = "Paciente"
        } else {
            if (perfil === "D") {
                perfilUsuario = "Dentista"
            } else {
                if (perfil === "R") {
                    perfilUsuario = "Recepcionista"
                }
            }
        }
    }
    return (
        <header className={styles.cabecalho}>
            <img className={styles.logo} src={logo} alt='Logo' />
            <h3>Perfil: {perfilUsuario}</h3>
        </header>
    )
}
