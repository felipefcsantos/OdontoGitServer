import React from 'react'
import Botao from '../Botao'
import styles from './TelaErro.module.css'
import imagem from './nao-encontrado.png'

export default function TelaErro() {
  return (
    <div className={styles.container}>
        <img src={imagem} alt='Usuário não encontrado'/>
        <p>Usuário não encontrado!</p>
        <Botao url='/'>Tentar Novamente</Botao>
    </div>
  )
}
